<HTML>
<BODY>
<H1> TRAITEMENT </H1>

<?php
	echo $_POST["Utilisateur"];
	echo "<BR>".$_POST["MotDePasse"];
    try{
		$db = new PDO('sqlite:'.dirname(__FILE__).'/DB/sqlite_connexion'); 
		$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // ERRMODE_WARNING | ERRMODE_EXCEPTION | ERRMODE_SILENT		
		$stmt = $db->prepare("select * from connexion where name= :nom and password= :pwd and actif=1 limit 1");
		$stmt->execute(array(':nom' => $_POST["Utilisateur"], ':pwd' => $_POST["MotDePasse"]));
		$result = $stmt->fetchAll();
		if ($result==NULL) {
			echo "PAS D'ENREGISTREMENT";
			// Code pour retourner sur la page d'identification
			header("Location: http://212.83.191.218/index.php");
		} else {
			// Code pour effectuer la redirection vers l'url
			foreach ($result as $row) {
				$redirectionURL=$row['url'];
				echo "<BR> URL : ".$redirectionURL;
				header("Status: 301 Moved Permanently", false, 301);
				//header("Location: http://www.free.fr");
				header("Location: ".$redirectionURL);
				exit();
		}
		}
		
	} catch(Exception $e) {
		echo "Impossible d'accéder à la base de données SQLite : ".$e->getMessage();
		die();
	}

		
?>
</BODY>
</HTML>

