<HTML>
<BODY>
<H1> TRAITEMENT </H1>

<?php
	echo $_POST["Utilisateur"]."    -    ".$_POST["Password"]." - ".$_POST["identifiant"]." Fin<BR>";

	try{
		$db = new PDO('sqlite:'.dirname(__FILE__).'/DB/sqlite_connexion'); 
		$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // ERRMODE_WARNING | ERRMODE_EXCEPTION | ERRMODE_SILENT
		if(!$db)
		{
			echo "Could not open/access DB";
		}		
		$query="update connexion SET name ='".$_POST["Utilisateur"]."',password = '".$_POST["Password"]."' where id=".$_POST["identifiant"];
		$stmt = $db->prepare($query);
		$stmt->execute();
		header("Location: http://212.83.191.218/administration.php");
		echo "OK...";
		$db.close();
	}
	catch(Exception $e) {
	echo "Impossible d'accéder à la base de données SQLite : ".$e->getMessage();
	}
	
?>
</BODY>
</HTML>