<HTML>
<HEADER>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</HEADER>
<BODY class="p-3 mb-2 bg-secondary text-white">
<div class="container p-3 mb-2 bg-secondary text-white">
	<H1 class="display-3 text-center text-uppercase"> Administration des comptes </H1><BR><BR>
<table class="table">
    <thead>
        <tr>
            <th scope="row">#</th><th>Id</th><th>Utilisateur</th><th>Mot de passe</th>
        </tr>
    </thead>
    <tbody>	
<?php
	try{
		$db = new PDO('sqlite:'.dirname(__FILE__).'/DB/sqlite_connexion'); 
		$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // ERRMODE_WARNING | ERRMODE_EXCEPTION | ERRMODE_SILENT		
		$stmt = $db->prepare("select name,password from connexion");
		$stmt->execute();
		$result = $stmt->fetchAll();
		$i=1;
		if ($result==NULL) {
			echo "PAS D'ENREGISTREMENT";
		} else {
			foreach ($result as $row) {
				echo "<TR>";
				echo "<th scope='row'>".$i."</th>";
				echo '<form method="post" action="traitement2.php">';
				echo "<TD>";
				echo '<input type="text" class="form-control" name="identifiant" id="identifiant" value="'.$i.'"size="5" maxlength="10" readonly />';
				echo "</TD>";
				echo "<TD>";
				echo '<input type="text" class="form-control" name="Utilisateur" id="Utilisateur" value="'.$row['name'].'"placeholder="Ex : robert" size="30" maxlength="10" />';
				echo "</TD>";
				echo "<TD>";
				echo '<input type="text" class="form-control" name="Password" id="Password" value="'.$row['password'].'"placeholder="Ex : robert" size="30" maxlength="10" />';
				echo "</TD>";
				echo "<TD>";
				echo '<input type="submit" class="btn btn-primary btn-lg btn-block" value="Mise à jour" />';
				echo "</TD>";
				echo '</FORM>';
				echo "</TR>";
				$i=$i+1;
			}
		}
	}
	catch(Exception $e) {
	echo "Impossible d'accéder à la base de données SQLite : ".$e->getMessage();
	}
	$db.close();
?>		
	</tbody>
</table>
</div>
</BODY>
</HTML>