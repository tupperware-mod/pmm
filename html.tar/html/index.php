
<HTML>
<HEADER>
<!--<link rel="stylesheet" type="text/css" href="/style.css" /> -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</HEADER>
<BODY class="p-3 mb-2 bg-secondary text-white">
<div class="container p-3 mb-2 bg-secondary text-white">
	<H1 class="display-3 text-center text-uppercase"> Formulaire de connexion </H1><BR><BR>
	<form method="post" action="traitement.php">
		<div class="form-group">
			<label for="Utilisateur">Utilisateur :</label>
			<input type="text" class="form-control" name="Utilisateur" id="Utilisateur" placeholder="Ex : robert" size="30" maxlength="10" />
		</div>
		<div class="form-group">
			<label for="MotDePasse">Mot de passe :</label>
			<input type="password" class="form-control" name="MotDePasse" id="MotDePasse" placeholder="Ex : mon mot de passe" size="30" maxlength="10" />
			<BR>
			<input type="submit" class="btn btn-primary btn-lg btn-block" value="Connexion" />
		</div>
	</form>
</div>
</BODY>
</HTML>

